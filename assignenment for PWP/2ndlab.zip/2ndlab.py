i=me=u=none=45
print(i,u,me,none)

x=45 ;y=45
print(x+y)

i= "Aryan";
u= "Mistery";
print(u+" "+i);
j="complex number"
print(j[1:3])
print(j[1::])
print(j[2::])
print(j[::1])
print(j[::2])
print(j[::-1])
print(j[-1::])
print(j[-7:-2])
print(j[::-1])
print(j[:7])
#usb in funcion or not in to seacrh in string and staff
print('a' in 'downlaod')

print('A' in 'downlaod')

#string oprator 

j="complex number"*3
print(j*3)
#string comparion
str1="NEW WOLRD SECOND HALF OF GRANDLINE"
str2="FIRST HALF OF GRANDLINE"
print(str1==str2)
print(str1!=str2)
#Escape Sequence Operator 
#str3= ""NEW WOLRD" SECOND HALF OF GRANDLINE" # this line gives error to solve this we use escape sequance
str3= "\"NEW WOLRD\" SECOND HALF OF GRANDLINE"
print(str3)
#string formatting oprator "%"

name ="no_study" 
age= 19 
marks =20.68 
str4= "Hey  i do %s"%(name)
print(str4)
str5= "i am not doing %s for %d  years"%(name,age)
print(str5)
str6= " hey %s I haven't done study for %d with %d" %(name ,age,marks) 
print(str6)





str1="your name"
str2="silent voice "
print(str1==str2)
print(str1!=str2)
print(str1+ " and "+ str2)
str7= "rishit you must watch one peice it is real"
print(str7)
print(str1,str2)
#string function 
str2="killing a mockingbird"
print(len(str2))
COunt=str2.count("i")
print(COunt)

print(str2.title())
print(str2.lower())
print(str2.upper())
m= "4"
print (ord(m))
x="                Aryan Mahida                   "

print(x[-4:-1])
print(x[3:8])
print(x.islower())
print(x.istitle())
print(x.isupper())
print(x)
print(x.strip())
print(x.lstrip())
print(x.rstrip())
print(x.find('a'))
print(x.rfind('a'))
print(x.find('L'))
print(x.replace('Aryan','Mahida'))
print(x.replace(" ", ''))
#ONE TASK 
x="Mahida"
print(x.find('a'))
print(x.replace('Mahida','Mahidb'))
print(x.replace(x[5],'b'))
print(x)
# y=x.rfind('a')
# print(x.replace((x[y]),'b'))
print(x.index('a'))
print(x.rindex('a'))
print(x.isalnum())
x="Aryan $ Mahida"
print(x.isalnum())
print(x.isdecimal())
print(x.isdigit())





